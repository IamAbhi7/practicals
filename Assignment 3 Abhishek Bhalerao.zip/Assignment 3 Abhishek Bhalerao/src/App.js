//import logo from './logo.svg';
import './App.css';
// import Button from './components/Button';
import Card from './components/Card';
// import Button from './components/Button';
import Navbar from './components/Navbar.js'
import Keypress from './components/Keypress.js'


function App() {
  return (
    <div>
      <Navbar/>
      <div className='main'>
        <Card color="#020236"/>
        <Card color="Green"/>
        <Card color="gray"/>
        <Keypress/>       
      </div>
    </div>
  );
}

export default App;
