import React, { Component } from 'react';

export default class DisplayInput extends Component {

  constructor(props) {
    super(props)

    this.state = {
       text : ''
    }
  }

  handleKeyPress = (event) => {
    this.setState({
      text : event.target.value
    })
  }

  render() {
    return (
      <div>
        <input type='text' onChange={this.handleKeyPress}></input>
        <h1>{this.state.text}</h1>
      </div>
    )
  }
}