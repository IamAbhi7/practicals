import '../Styles/Footer.css'

// function component 
function Footer() {
  return (
    <footer className="main-footer">
		<div className="container">
			<div className="copyright text-center">
				<p>&copy; 2019 All rights reserved</p>
			</div>
		</div>
	  </footer>
  )
}

export default Footer