import React, { Component } from 'react'
import Button from './Button'
import '../Styles/Card.css'

class Card extends Component {
  constructor(props){
    super(props)
    this.state = {
      msg : "",
      cls : 0
    }
  }

   getWord(){
  
    var theWord= [
      'one',
      'two',
      'three',
      'four',
      'five',
      'six',
    ];

    var wordNum = Math.floor(Math.random() * theWord.length);
    
    var word = theWord[wordNum];
    return word;
  }

  display = () => {
    this.setState({
      msg: `${this.getWord()}`,
      cls: 1
    })
  }

  // get = this.props.color
  render() {
    return (
      <div className="card">
        <h1>{this.state.msg}</h1>
        <Button Show={this.display} value="Show" co={this.props.color}  />
      </div>
    )
  }
}

export default Card