import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent {

  tableData = [
    { id: 1, name: 'Abhishek' },
    { id: 2, name: 'Rajesh' },
    { id: 3, name: 'Vishal' },
  ];
  receivedData: string = '';

  receiveDataFromChild(data: string) {
    this.receivedData = data;
  }
}
