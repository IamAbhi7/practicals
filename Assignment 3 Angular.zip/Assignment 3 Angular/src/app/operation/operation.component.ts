import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.scss']
})
export class OperationComponent {

  public name = "Abhishek";
  public str = "";
  public s="";
  public add=0;
  public sub=0;
  public mul=1;
  public div=1;
  public result=1;
  public isTrue =false;

  public showAdd(val1 :string,val2 :string){
    this.result = parseFloat(val1) + parseFloat(val2);
    this.isTrue=true;
    alert(this.result);
  }

  public showSub(val1 :string,val2 :string){
    this.result = parseFloat(val1) - parseFloat(val2);
    this.isTrue=true;
    alert(this.result)
  }

  public showMul(val1 :string,val2 :string){
    this.result = parseFloat(val1) * parseFloat(val2);
    this.isTrue=true;
    alert(this.result)
  }

  public showDiv(val1 :string,val2 :string){
    this.result = parseFloat(val1) / parseFloat(val2);
    this.isTrue=true;
    alert(this.result)
  }

  /**
   * handleClick
   */
  public handleClick() {
    this.str = "The End"
  }


}
