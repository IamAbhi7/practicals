import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { OperationComponent } from './operation/operation.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { TestComponent } from './test/test.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainComponent } from './main/main.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: 'Communication', component: TestComponent },
  { path: 'Operation', component: OperationComponent },
  // { path: 'Home',component: MainComponent}
  // Add more routes as needed
];

@NgModule({
  declarations: [
    AppComponent,
    OperationComponent,
    NavbarComponent,
    FooterComponent,
    TestComponent,
    SidebarComponent,
    MainComponent 
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [MainComponent,AppComponent]
})
export class AppModule { }
