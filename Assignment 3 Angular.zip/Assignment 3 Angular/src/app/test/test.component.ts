import { Component,Input,Output,EventEmitter } from "@angular/core";

@Component({
  selector:'app-test',
  templateUrl:'./test.component.html',
  styleUrls:['./test.component.scss']
})

export class TestComponent{
  @Input() data: any[] = [];
  @Output() sendData = new EventEmitter<string>();

  sendDataToParent() {
    // You can send data to the parent component here 
    this.sendData.emit('Data from child to parent');
  }
}