﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class BookShopsController : Controller
    {
        private BookStoreEntities1 db = new BookStoreEntities1();

        // GET: BookShops
        public ActionResult Index()
        {
            return View(db.BookShops.ToList());
        }

        // GET: BookShops/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BookShop bookShop = db.BookShops.Find(id);
            if (bookShop == null)
            {
                return HttpNotFound();
            }
            return View(bookShop);
        }

        // GET: BookShops/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult CreateBook(BookShop bookShop)
        {
            if (ModelState.IsValid)
            {
                BookStoreEntities1 bookStore = new BookStoreEntities1(); 
                bookStore.BookShops.Add(bookShop);
                bookStore.SaveChanges();
                return RedirectToAction("Index");
            }

            return View();
        }

        public ActionResult Edit(int id)
        {
            if(id != 0)
            {
                BookStoreEntities1 bookStore = new BookStoreEntities1();
                var book = bookStore.BookShops.Where(x => x.Bookid == id).FirstOrDefault();
                return View(book);
            }
            return View();
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit(BookShop bookShop)
        {
            if (ModelState.IsValid)
            {
                BookStoreEntities1 bookStore = new BookStoreEntities1();
                bookStore.Entry(bookShop).State = EntityState.Modified;
                bookStore.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(bookShop);
        }

        

        // POST: BookShops/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Bookid,Title,Author,Description,Price,Image")] BookShop bookShop)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.BookShops.Add(bookShop);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(bookShop);
        //}

        // GET: BookShops/Edit/5
        //public ActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    BookShop bookShop = db.BookShops.Find(id);
        //    if (bookShop == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(bookShop);
        //}

        //// POST: BookShops/Edit/5
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit([Bind(Include = "Bookid,Title,Author,Description,Price,Image")] BookShop bookShop)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(bookShop).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(bookShop);
        //}

        // GET: BookShops/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BookShop bookShop = db.BookShops.Find(id);
            if (bookShop == null)
            {
                return HttpNotFound();
            }
            return View(bookShop);
        }

        // POST: BookShops/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BookShop bookShop = db.BookShops.Find(id);
            db.BookShops.Remove(bookShop);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
