import React from 'react';
import Navbar from "./Components/Navbar";
import Banner from './Components/Banner';
import Footer from './Components/Footer';
import Keypress from './Components/Keypress'
import Card from './Components/Card';
import './App.css'


function App() {
	return (
		<React.Fragment>
			<div className='page-wrapper'>
			<Navbar/>
			<Banner/>
			<Card/>
			<Keypress/>
			</div>
			<Footer/>
		</React.Fragment>
	);
}

export default App;
