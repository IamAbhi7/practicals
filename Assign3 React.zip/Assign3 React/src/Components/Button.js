import React, { Component } from 'react'
import '../Styles/Button.css'

class Button extends Component {

  render() {
    return (
      <div>
        {/* button component  */}
        <button onClick={this.props.Show} style={{
          backgroundColor: `${this.props.color}`
        }}>{this.props.value}
        </button>
      </div>
    )
  }
}

export default Button
