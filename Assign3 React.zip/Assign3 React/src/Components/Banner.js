import React from 'react'
import '../Styles/Banner.css'

function Banner() {
  return (
    <div className='img'>
      <h1 className='welcome'>Welcome to the Authors section</h1>
    </div>
  )
}

export default Banner