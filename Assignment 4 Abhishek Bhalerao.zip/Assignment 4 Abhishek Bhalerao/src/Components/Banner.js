import React from 'react'
import '../Styles/Banner.css'

function Banner() {
  return (
    <div className='img'>
      <h1 className='welcome'>Form Validation</h1>
    </div>
  )
}

export default Banner