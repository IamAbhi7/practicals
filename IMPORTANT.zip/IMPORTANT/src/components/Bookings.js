import React from 'react'

function Bookings() {
  return (
    <div>Bookings</div>
  )
}

export default Bookings