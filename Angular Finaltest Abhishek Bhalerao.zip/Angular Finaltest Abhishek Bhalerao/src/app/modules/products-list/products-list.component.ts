import { Component, OnInit } from '@angular/core';
import { ProductService } from './product-service.service';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.scss']
})
export class ProductsListComponent {
  products: any[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(
      (data: any) => {
        console.log(data)
        this.products = data.body;
      },
      (error: any) => { 
        console.error('Error fetching products:', error);
      }
    );
  }
}
