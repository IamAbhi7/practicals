// show current date 
function find_currDate(){
  let current = new Date();
  let year = current.getFullYear();
  let date = current.getDate();
  let month = current.getMonth() + 1;

  let actmonth;
  let actdate;

  (month<10) ? actmonth = '0' + month : actmonth = month;
  (date<10) ? actdate = '0' + date : actdate = date;

  let first = actmonth + '-' + actdate + '-' + year;
  let second = actmonth + '/' + actdate + '/' + year;
  let third = actdate + '-' + actmonth + '-' + year;
  let fourth = actdate + '/' + actmonth + '/' + year;
  

  let currDates = document.querySelectorAll('[id^="currDate_"]');
  for(let index = 0; index < currDates.length; index++){ 
    if(currDates[index].type == 'radio' && currDates[index].checked == true && index==0) {
      document.getElementById('sel_currDate').innerHTML = 'Selected Date is: ' + first;
      break;
    }
    if(currDates[index].type == 'radio' && currDates[index].checked == true && index==1) {
      document.getElementById('sel_currDate').innerHTML = 'Selected Date is: ' + second;
      break;
    }
    if(currDates[index].type == 'radio' && currDates[index].checked == true && index==2) {
      document.getElementById('sel_currDate').innerHTML = 'Selected Date is: ' + third;
      break;
    }
    if(currDates[index].type == 'radio' && currDates[index].checked == true && index==3) {
      document.getElementById('sel_currDate').innerHTML = 'Selected Date is: ' + fourth;
      break;
    }
  }
}

// Show city based on selected country
function show_dropdown(sel_option){
  if (sel_option == ''){
    document.getElementById("indiaCities").style.display = "none";
    document.getElementById("italyCities").style.display = "none";
    document.getElementById("australiaCities").style.display = "none";
  }else if (sel_option == 'India'){
    document.getElementById("indiaCities").style.display = "block";
    document.getElementById("italyCities").style.display = "none";
    document.getElementById("australiaCities").style.display = "none";
  } else if (sel_option == 'Italy'){
    document.getElementById("indiaCities").style.display = "none";
    document.getElementById("italyCities").style.display = "block";
    document.getElementById("australiaCities").style.display = "none";
  } else {
    document.getElementById("indiaCities").style.display = "none";
    document.getElementById("italyCities").style.display = "none";
    document.getElementById("australiaCities").style.display = "block";
  }
}
function show_city(sel_option){
  document.querySelector("#display_city").innerHTML = sel_option;
}

//function to display count of selected checkboxes
function show_topic(){
  let count = 0;
  var ele = document.getElementsByName('chk');
  var all_checked = true;
  for (var index = 0; index < ele.length; index++){
    if(ele[index].type == 'checkbox' && ele[index].checked == true) {
      count++;
    }    
  }
  document.getElementById('sel_topics').innerHTML = 'Selected colors: '+ count;
}


// removing rows from table 
let buttons = document.getElementsByClassName("remove");
// for(let i=0;i<buttons.length;i++){
//   buttons[i].onclick = function(event){
//     let parent = event.target.parentNode.parentNode;
//     parent.remove();
//   }
// }
let yesNo = document.getElementsByClassName("yes-no");
for(let i=0;i<buttons.length;i++){
  buttons[i].addEventListener('click',function(event){
    let parent = event.target.parentNode.parentNode;
    let hidden = document.querySelector(".box1");
    hidden.style.display = "block";
    for(let i=0;i<yesNo.length;i++){
      if(i==0){
        yesNo[0].onclick = function(event){
          parent.remove();
          hidden.style.display = "none";
        }
      }
      if(i==1){
        yesNo[1].onclick = function(event){
          hidden.style.display = "none";
        }
      }
    }
  });
}


// 5. calculate total price

let rowArray = document.getElementsByClassName("row-array");
let i = rowArray.length;
console.log(i);

// let mainForm = document.getElementById("main-form");
let addRow = document.getElementById("add-row").innerHTML;
let calControl = document.getElementById("cal-control");
let totalAmount = document.getElementById("total-amount");

let calBtn = document.getElementById("calculate");
let addMore = document.getElementById("add-more");
let showTotal= document.getElementById("show-total");

let grandTotal = 0;
// let i = rowArray.length - 1;
calBtn.addEventListener('click',function(){
  let j = rowArray.length;
  console.log(j);
  let productName = rowArray[rowArray.length - 1].children[0].children[0];
  let quantity = rowArray[rowArray.length - 1].children[1].children[0];
  let price = rowArray[rowArray.length - 1].children[2].children[0];
  let total = rowArray[rowArray.length - 1].children[3].children[0];
  if(productName.value=='' || quantity.value=='' || price.value==''){
    alert("please Enter the details");
  }else{
    total.value = parseFloat(quantity.value) * parseFloat(price.value);
    grandTotal += parseFloat(total.value);
  }
});

addMore.addEventListener('click',function(){
  let total = rowArray[rowArray.length - 1].children[3].children[0];
  if(total.value == ''){
    alert("please calculate the total")
  }else{
    let newRow = "<div class='row form-group row-array'>" + addRow + "</div>";
    calControl.insertAdjacentHTML('beforebegin',newRow);
  }
})

showTotal.addEventListener('click',function(){
  totalAmount.innerText = "Grand total is: " + grandTotal;
})










