// jQuery(document).ready(function($) {

// //wow init script for animate css
// new WOW().init();

// });

// function myFun() {
//   let firstName = document.getElementById("firstName").value;
//   let lastName = document.getElementById("lastName").value;

//   let toCapitalFirst =
//     firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase();
//   let toCapitalLast =
//     lastName.charAt(0).toUpperCase() + lastName.slice(1).toLowerCase();

//   let fullname = toCapitalFirst + " " + toCapitalLast;

//   document.getElementById("output").innerHTML = fullname;
// }

function displayFullName() {
  // Get input values
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;

  // Capitalize first letter of first name and last name
  const capitalizedFirstName = firstName.charAt(0).toUpperCase() + firstName.slice(1);
  const capitalizedLastName = lastName.charAt(0).toUpperCase() + lastName.slice(1);

  // Combine first name and last name
  const fullName = capitalizedFirstName + ' ' + capitalizedLastName;

  // Display full name
  const fullNameResult = document.getElementById('fullNameResult');
  fullNameResult.textContent = 'Full Name: ' + fullName;
}

function replaceWord() {
  let inputstring = document.getElementById("inputString").value;
  let newWord = document.getElementById("newWord").value;
  let oldWord = document.getElementById("oldWord").value;

  let modifiedString = inputstring.replace(oldWord,newWord);
  document.getElementById("Result").innerText = modifiedString;
}

function reverseWord(){
  let word  = document.getElementById("word").value;
  let arr = word.split("");
  let revArr = arr.reverse();
  let revWord = revArr.join("");

  document.getElementById("reverseWord").innerHTML = revWord;
}

function roundOff(){
  let num = document.getElementById("num").value;
  let roundOff = Math.round(num);

  document.getElementById("round").innerHTML = roundOff; 
}

function updateDateTime() {
  var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  var now = new Date();
  var dayOfWeek = days[now.getDay()];
  var month = months[now.getMonth()];
  var day = now.getDate();
  var year = now.getFullYear();
  var hours = now.getHours();
  var minutes = now.getMinutes();
  var seconds = now.getSeconds();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  
  var datetimeString = "Today is: " + dayOfWeek + ". Current time is: " + hours + " " + ampm + " : " + 
                       (minutes < 10 ? '0' + minutes : minutes) + " : " + (seconds < 10 ? '0' + seconds : seconds);
  
  document.getElementById("datetime").textContent = datetimeString;
}
