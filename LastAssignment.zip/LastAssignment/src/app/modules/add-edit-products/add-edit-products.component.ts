import { Component,EventEmitter,Input,Output } from '@angular/core';
import { FormControl, FormGroup  } from '@angular/forms';

import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../products-list/product-service.service';

@Component({
  selector: 'app-add-edit-products',
  templateUrl: './add-edit-products.component.html',
  styleUrls: ['./add-edit-products.component.scss']
})
export class AddEditProductsComponent {

    @Input() product: any;
    @Output() close = new EventEmitter();

    public productForm = new FormGroup({   
      name: new FormControl(""),
      price: new FormControl("")
    });

    constructor(private productService : ProductService,
      private toastrService : ToastrService){} 

    ngOnInit(){
      if(this.product){
        this.productForm.patchValue(this.product)
      }
    }

    public onClose(): void{
      this.close.emit();
    }

    public save(): void{
        let payload = this.assignValueToModel();
        if(!this.product){
          this.addProduct(payload);
        }else{
          this.updateProduct(payload);
        }
    }

    public delete(): void{
      let payload = this.assignValueToModel();
      // if(!this.product){
      //   this.addProduct(payload);
      // }else{
      //   this.updateProduct(payload);
      // }
    }

    private addProduct(payload: any): void{
      this.productService.addProduct(payload).subscribe((response: any) => {
        this.toastrService.success("Product added successfully","Success");
        this.onClose();
      },(error: any) => {
        this.toastrService.error("Error adding product","Error")
      });
    }

    private updateProduct(payload: any): void{
      this.productService.updateProduct(payload).subscribe((response: any) => {
        this.toastrService.success("Product updated successfully","Success");
        this.onClose();
      },(error: any) => {
        this.toastrService.error("Error updated product","Error")
      });
    }

    private deleteProduct(payload: any): void{
      this.productService.deleteProduct(payload).subscribe((response: any) => {
        this.toastrService.success("Product deleted successfully","Success");
        this.onClose();
      },(error: any) => {
        this.toastrService.error("Error deleted product","Error")
      });
    }

    private assignValueToModel(): any{
      let product = {
        "id": this.product ? this.product.id : 0,
        "name": this.productForm.get("name")?.value,
        "price":this.productForm.get("price")?.value,
      };  
      return product;
    }
}
