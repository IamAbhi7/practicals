//import logo from './logo.svg';
import './App.css';
import ArrayMethod from './components/ArrayMethod';
import DataTypes from './components/DataTypes';

function App() {
  return (
    <div className="App">
      <DataTypes/>
      <ArrayMethod/>
    </div>
  );
}

export default App;
