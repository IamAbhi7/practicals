

//Declaring and assigning variables using let
let usingLet = () => {
  let x = 1;
  if(x<5){
     let x = 2;
  }
  return x;
}

//Declaring and assigning variables using const
const usingConst = () => {
  const employee ={
    name:"Abhishek",
    age:"22"
  }
  //we can modify the values of object keys even though it is a const variable
  employee.name = "Rahul";
  return employee.name;
}

//Declaring and assigning variables using let
var usingVar = () => {
  var a = 3;
  if(a>0){
     var a = 4;
  }
  return a;
}


const DataTypes = () =>{
  return(
    <div>
      <h1>DataTypes(let,const,var)</h1>
      <h2>Value of x is {usingLet()}</h2>
      <h2>Value of property name is {usingConst()}</h2>
      <h2>value of z is {usingVar()}</h2>
    </div>
  );
}

export default DataTypes;