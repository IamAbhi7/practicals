import React, { Component } from 'react'




class ArrayMethod extends Component{
  

  render(){
    let marks = [90,88,94,89,78];

    const marksIncre = marks.map((mark) => {
    return (mark+5+" ");
    })
    
    const distinctionMarks = marks.filter((mark) => {
      if(mark>90){
        return (mark);
      }
    })

    const totalMarks = marks.reduce((result,mark) =>{
      return (result+mark);
    }) 

    let y = 23;
    let z = 76;
    let moreMarks = [...marks,y,z]
    let allMarks = moreMarks.map((mark) => {
      return (mark+" ");
    })

    let num1,num2,others;
    [num1,num2,...others] = marks
    const total = others.map((ele) => {
      return (ele+" ")
    })
    






    return (
      <div>
        <h2>{marksIncre}</h2>
        <h2>{distinctionMarks}</h2>
        <h2>{totalMarks}</h2>
        <h2>{allMarks}</h2>
        <h2>{total}</h2>
      </div>
    );
  } 
}

export default ArrayMethod;