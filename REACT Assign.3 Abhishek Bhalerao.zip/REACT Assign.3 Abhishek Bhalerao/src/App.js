import React from 'react';
import Navbar from "./Components/Navbar";
import Banner from './Components/Banner';
import Static from './Components/Static';
import Footer from './Components/Footer';
// import Button from './Components/Button';
import Keypress from './Components/Keypress'
import Card from './Components/Card';


function App() {
	return (
		<React.Fragment>
			<Navbar/>
			<Banner/>
			<Static/>
			<Card/>
			<Keypress/>
			<Footer/>
		</React.Fragment>
	);
}

export default App;
