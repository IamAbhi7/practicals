import React from 'react'
import '../Styles/Static.css'

function Static() {
  return (
    <div>
			{/* static section  */}
      <div className="service-section">
				<div className="container">
					<div className="row">
						<div className="col">
							<div className="section-header wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="10ms">
								<h2>SERVICES</h2>
								<div className="rule"></div>
								<p>Neque porro quisquam est,qui dolorem ipsum quia dolor sit amet consectetur, adipisci velit, sed quia
									non
									numquam</p>
							</div>
						</div>
					</div>
					<div className="row icon-section">
						<div className="col-lg-5 service-col wow fadeInLeft cards" data-wow-duration="1000ms" data-wow-delay="100ms">
							<div className="service-box clearfix">
								<figure className="image-outer">
									<i className="fas fa-chart-bar"></i>
								</figure>
								<div className="text-content">
									<h3>Lorem ipsum</h3>
									<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut eligendi quo est id, nobis,
										accusantium maior.</p>
								</div>
							</div>
						</div>
						<div className="col-lg-5 service-col  wow fadeInUp cards" data-wow-duration="1000ms" data-wow-delay="200ms">
							<div className="service-box clearfix">
								<figure className="image-outer">
									<i className="far fa-image"></i>
								</figure>
								<div className="text-content">
									<h3>Dolor Sitema</h3>
									<p>adipisicing elit. Ab accusamus doloremque perferendis neque quisquam, perspiciatis fugiat officiis
										vitae deleniti consequatur quia?</p>
								</div>
							</div>
						</div>
						<div className="col-lg-5 service-col wow fadeInUp cards" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div className="service-box clearfix">
								<figure className="image-outer">
									<i className="fas fa-shopping-bag"></i>
								</figure>
								<div className="text-content">
									<h3>Sed ut perspiciatis</h3>
									<p>Ab accusamus doloremque perferendis neque quisquam, perspiciatis fugiat officiis vitae deleniti
										ducimus molestiae magnam.</p>
								</div>
							</div>
						</div>
						<div className="col-lg-5 service-col wow fadeInUp cards" data-wow-duration="1000ms" data-wow-delay="400ms">
							<div className="service-box clearfix">
								<figure className="image-outer">
									<i className="fa fa-map"></i>
								</figure>
								<div className="text-content">
									<h3>Magni Dolores</h3>
									<p>perspiciatis fugiat officiis vitae deleniti ducimus molestiae magnam, aperiam aliquid quis
										temporibus molestias obcaecati</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
    </div>
  )
}

export default Static