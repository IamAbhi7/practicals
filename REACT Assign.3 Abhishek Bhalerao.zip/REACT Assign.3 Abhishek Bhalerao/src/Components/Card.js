import React, { Component } from 'react'
import Button from './Button'
import '../Styles/Card.css'
import jsons from '../JsonObj/quotes.json'


// &#x201C;
// &#x201D;

class Card extends Component {
  constructor(props){
    super(props)
    this.state = {
      msg : "",
      co : ""
    }
  }

  getWord(){
    const qoutesFile = jsons
    const quote = JSON.stringify(qoutesFile)
    const q = JSON.parse(quote)

    var wordNum = Math.floor(Math.random() * q.length-1)  
    var word = q[wordNum].quote
    return word
  }

  getColor(){
    var clrs = ['blue','yellow','red','gray','pink']
    var randomClr = Math.floor(Math.random() * clrs.length-1)
    var clr = clrs[randomClr]
    return clr
  }

  display = () => {
    this.setState({
      msg: `${this.getWord()}`
    })
  }

  changeColor = () => {
    this.setState({
      co: `${this.getColor()}`
    })
  }

  // get = this.props.color
  render() {
    return (
      <div className="card" style={{
        backgroundColor:`${this.state.co}`
      }}>
        <h2>{this.state.msg}</h2>
        <div className='btns'>
        <Button Show={this.display} value="Show" color="green"  />
        <Button Show={this.changeColor} value="change Color" color={this.props.color}/>
        </div>
      </div>
    )
  }
}

export default Card