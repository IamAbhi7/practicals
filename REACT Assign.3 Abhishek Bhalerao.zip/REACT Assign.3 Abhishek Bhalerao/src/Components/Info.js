import React from 'react'

function Info(props){
  return (
    <div style={{textAlign:'center'}}>
      <h1>Hello {props.name}</h1>
    </div>
  )
}

export default Info