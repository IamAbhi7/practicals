import React, { Component } from 'react';
import './Button'
import Button from './Button';

export default class DisplayInput extends Component {

  constructor(props) {
    super(props)

    this.state = {
       text : ''
    }
  }

  handleKeyPress = (event) => {
    this.setState({
      text : event.target.value,
      visibility : 'none'
    })
  }

  block = () =>{
    this.setState({
      visibility : 'block'
    })
  }

  render() {
    return (
      <div>
        <input type='text' onChange={this.handleKeyPress}></input>
        <Button color='green' Show={this.block} value='Display' />
        <h1 style={{
          display:`${this.state.visibility}` 
        }}>{this.state.text}</h1>
      </div>
    )
  }
}