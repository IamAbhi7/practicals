import React, { Component } from 'react'
import '../Styles/Message.css'

// message class 
class Message extends Component {
  //Constructor
  constructor() {
    super()
    this.state = {
       msg: 'Click on a button for a change'
    }
  }

  //display button event
  display(){
    this.setState({
      msg: "You can change me only once"
    })
  }

  render() {
    return (
      <div className="msg">
        <h2>{this.state.msg}</h2>
        <button onClick={() => this.display()} >Display</button>
      </div>
    )
  }
}

export default Message