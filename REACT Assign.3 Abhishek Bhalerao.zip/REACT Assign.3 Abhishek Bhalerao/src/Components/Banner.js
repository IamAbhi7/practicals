import React from 'react'
import mainBanner from '../sabri-tuzcu-wunVFNvqhfE-unsplash.jpg'
import '../Styles/Banner.css'

function Banner() {
  return (
    <div>
      {/* banner image  */}
      <img src={mainBanner} alt='main-banner'/>
    </div>

  )
}

export default Banner