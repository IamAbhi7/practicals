
const marks = [90,88,94,89,78];

const useSpread = () =>{
  let y = 23;
  let z = 76;
  let moreMarks = [...marks,y,z]
  let allMarks = moreMarks.map((mark) => {
    return (mark+" ");
  })
  return allMarks;
}

const useRest = () =>{
  let num1,num2,others;
  [num1,num2,...others] = marks
  const total = others.map((ele) => {
    return (ele+" ")
  })
  return total;
}


const SpreadRest = () =>{
  return(
    <div className="SpreadRest" 
         style={{
          border:'1px solid black',
          width:'30%',
          display:'flex',
          flexDirection:'column',
          margin:'auto',
          textAlign:'center',
          boxShadow: '3px 0 8px gray'
         }}>
      <h2>Spread and Rest</h2>
      <h3>Use of spread operator <br/>moreMarks: {useSpread()}</h3>
      <h3>Use of rest operator <br/>others: {useRest()}</h3>
    </div>
  );
}

export default SpreadRest;