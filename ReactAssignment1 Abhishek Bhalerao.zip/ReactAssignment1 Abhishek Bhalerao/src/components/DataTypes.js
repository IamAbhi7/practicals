

//Declaring and assigning variables using let
let usingLet = () => {
  let x = 1;
  if(x<5){
     let x = 2;
  }
  return x;
}

//Declaring and assigning variables using const
const usingConst = () => {
  const employee ={
    name:"Abhishek",
    age:"22"
  }
  //we can modify the values of object keys even though it is a const variable
  employee.name = "Rahul";
  return employee.name;
}

//Declaring and assigning variables using let
var usingVar = () => {
  var a = 3;
  if(a>0){
     var a = 4;
  }
  return a;
}


const DataTypes = () =>{
  return(
    <div  className="DataTypes"
          style={{
          border:'1px solid black',
          width:'30%',
          display:'flex',
          flexDirection:'column',
          margin:'auto',
          textAlign:'center',
          boxShadow: '3px 0 8px gray'
         }}>
      <h2>DataTypes(let,const,var)</h2>
      <h3>Value of x is {usingLet()}</h3>
      <h3>Value of property name is {usingConst()}</h3>
      <h3>value of z is {usingVar()}</h3>
    </div>
  );
}

export default DataTypes;