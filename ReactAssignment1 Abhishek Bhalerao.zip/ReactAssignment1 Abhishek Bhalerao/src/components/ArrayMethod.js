import React, { Component } from 'react'

class ArrayMethod extends Component{
  marks = [90,88,94,89,78];

  useMap = () => {
    const marksIncre = this.marks.map((mark) => {
    return (mark+5+" ");
    })
    return marksIncre;
  }

  useFilter = () => {
    const distinctionMarks = this.marks.filter((mark) => {
      if(mark>90){
        return (mark);
      }
    })
    return distinctionMarks
  }

  useReduce = () => {
    const totalMarks = this.marks.reduce((result,mark) =>{
      return (result+mark);
    }) 
    return totalMarks
  }

  render(){
    return (
      <div  className='ArrayMethod'
            style={{
            border:'1px solid black',
            width:'30%',
            display:'flex',
            flexDirection:'column',
            margin:'20px auto',
            textAlign:'center',
            boxShadow: '3px 0 8px gray'
         }}>
        <h2>Array Methods</h2>
        <h3>5 marks increment: {this.useMap()}</h3>
        <h3>Marks more than 90: {this.useFilter()}</h3>
        <h3>Sum of total marks: {this.useReduce()}</h3>    
      </div>
    );
  } 
}

export default ArrayMethod;