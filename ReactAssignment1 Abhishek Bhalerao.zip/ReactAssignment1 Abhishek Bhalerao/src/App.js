//import logo from './logo.svg';
import './App.css';
import ArrayMethod from './components/ArrayMethod';
import DataTypes from './components/DataTypes';
import SpreadRest from './components/SpreadRest';

function App() {
  return (
    <div>
      <DataTypes/>
      <ArrayMethod/>
      <SpreadRest/>
    </div>
  );
}

export default App;
