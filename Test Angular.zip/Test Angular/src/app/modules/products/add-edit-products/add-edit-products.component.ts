import { Component,EventEmitter,Input,Output } from '@angular/core';
import { FormControl, FormGroup, Validators, AbstractControl, ValidationErrors  } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../products-list/product-service.service';

@Component({
  selector: 'app-add-edit-products',
  templateUrl: './add-edit-products.component.html',
  styleUrls: ['./add-edit-products.component.scss']
})
export class AddEditProductsComponent {

  @Input() product: any;
  @Output() close = new EventEmitter();
  selectedDates: Date[] = []; 

  public productForm = new FormGroup({   
    name: new FormControl("",[Validators.required,Validators.minLength(2),Validators.pattern(/^[A-Za-z\s]+$/)]),
    quantity: new FormControl("",[Validators.required,Validators.max(50),Validators.min(1)]),
    price: new FormControl("",[Validators.required]),
    category: new FormControl("",[Validators.required]),
    review: new FormControl("",[Validators.required]),
    date: new FormControl("",[Validators.required, this.futureDateValidator.bind(this),this.uniqueDateValidator.bind(this)])
  });

  constructor(private productService : ProductService,
    private toastrService : ToastrService,
    private datePipe: DatePipe ){} 

  ngOnInit(){
    if(this.product){
      this.productForm.patchValue(this.product)
    }

    this.productService.getProducts().subscribe((products: any[]) => {
      this.selectedDates = products.map(product => new Date(product.date));
      // console.log(this.selectedDates);
    });
    
  }

  public getCurrentDate(): string {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Adding 1 because months are zero-based
    const day = String(currentDate.getDate()).padStart(2, '0');
  
    return `${year}-${month}-${day}`;
  }

  public onClose(): void{
    this.close.emit();
  }

  public save(): void{
      let payload = this.assignValueToModel();
      if(!this.product){
        this.addProduct(payload);
      }else{
        this.updateProduct(payload);
      }
  }

  private addProduct(payload: any): void{
    this.productService.addProduct(payload).subscribe((response: any) => {
      this.toastrService.success("Product added successfully","Success");
      this.onClose();
    },(error: any) => {
      this.toastrService.error("Error adding product","Error")
    });
  }

  private updateProduct(payload: any): void{
    this.productService.updateProduct(payload).subscribe((response: any) => {
      this.toastrService.success("Product updated successfully","Success");
      this.onClose();
    },(error: any) => {
      this.toastrService.error("Error updated product","Error")
    });
  }

  private assignValueToModel(): any {
    let product = {
      "id": this.product ? this.product.id : 0,
      "name": this.productForm.get("name")?.value,
      "quantity":this.productForm.get("quantity")?.value,
      "price": this.productForm.get("price")?.value,
      "category": this.productForm.get("category")?.value,
      "review": this.productForm.get("review")?.value,
      "date": this.productForm.get("date")?.value
    };  
    return product;
  }

  public checkIfControlValid(controlName: any): boolean{
    return this.productForm.get(controlName)?.invalid &&
    this.productForm.get(controlName)?.errors &&
      (this.productForm.get(controlName)?.dirty || this.productForm.get(controlName)?.touched) ? true : false;
  }

  public checkControlHasError(controlName: any, error: any): boolean {
    return this.productForm.get(controlName)?.hasError(error) ? true : false; 
  }

  private futureDateValidator(control: AbstractControl): ValidationErrors | null {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();

    if (selectedDate <= currentDate) {
      const formattedCurrentDate = this.datePipe.transform(currentDate, 'yyyy-MM-dd');
      return { futureDateRequired: true, currentDate: formattedCurrentDate };
    }

    return null; 
  }

  private uniqueDateValidator(control: AbstractControl): ValidationErrors | null {
    
    const currentDate = new Date();
    const selectedDate = new Date(control.value);
    console.log("current Date:", selectedDate.getDate());
    console.log("Selected Date:", selectedDate);
    
    if (selectedDate > currentDate) {
      if (this.selectedDates.some(existingDate =>
        selectedDate.getFullYear() === existingDate.getFullYear() &&
        selectedDate.getMonth() === existingDate.getMonth() &&
        selectedDate.getDate() === existingDate.getDate()
        )) {

          return { dateAlreadySelected: true };
        }
    }
        
    return null; 
  }

  
}
