import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  ngOnInit(){
    this.autoplayCarousel();
  }

  autoplayCarousel(): void {
    const carouselEl: HTMLElement | null = document.getElementById("carousel");
    const slideContainerEl: HTMLElement | null = carouselEl?.querySelector("#slide-container");
    const slideEl: HTMLElement | null = carouselEl?.querySelector(".slide");
    let slideWidth: number = slideEl?.offsetWidth || 0;

    // Add click handlers
    document.querySelector("#back-button")
        ?.addEventListener("click", () => navigate("backward"));
    document.querySelector("#forward-button")
        ?.addEventListener("click", () => navigate("forward"));
    document.querySelectorAll(".slide-indicator")
        .forEach((dot: Element, index: number) => {
            dot.addEventListener("click", () => navigate(index));
            dot.addEventListener("mouseenter", () => clearInterval(autoplay));
        });

    // Add keyboard handlers
    document.addEventListener('keydown', (e: KeyboardEvent) => {
        if (e.code === 'ArrowLeft') {
            clearInterval(autoplay);
            navigate("backward");
        } else if (e.code === 'ArrowRight') {
            clearInterval(autoplay);
            navigate("forward");
        }
    });

    // Add resize handler
    window.addEventListener('resize', () => {
        slideWidth = slideEl?.offsetWidth || 0;
    });

    // Autoplay
    const autoplay: number = setInterval(() => navigate("forward"), 3000);
    slideContainerEl?.addEventListener("mouseenter", () => clearInterval(autoplay));

    // Slide transition
    const getNewScrollPosition = (arg: string | number): number => {
        const gap: number = 10;
        const maxScrollLeft: number = slideContainerEl?.scrollWidth - slideWidth || 0;

        if (arg === "forward") {
            const x: number = (slideContainerEl?.scrollLeft || 0) + slideWidth + gap;
            return x <= maxScrollLeft ? x : 0;
        } else if (arg === "backward") {
            const x: number = (slideContainerEl?.scrollLeft || 0) - slideWidth - gap;
            return x >= 0 ? x : maxScrollLeft;
        } else if (typeof arg === "number") {
            const x: number = arg * (slideWidth + gap);
            return x;
        }

        return 0;
    }

    const navigate = (arg: string | number): void => {
        slideContainerEl!.scrollLeft = getNewScrollPosition(arg);
    }

    // Slide indicators
    const slideObserver = new IntersectionObserver((entries: IntersectionObserverEntry[], observer: IntersectionObserver) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // const slideIndex: string | undefined = entry.target.dataset.slideindex;
                // const slideIndex: string | undefined = (entry.target as HTMLElement).dataset.slideindex;
                const slideIndex: string | undefined = (entry.target as HTMLElement).dataset['slideindex'];


                carouselEl?.querySelector('.slide-indicator.active')?.classList.remove('active');
                carouselEl?.querySelectorAll('.slide-indicator')[slideIndex!]?.classList.add('active');
            }
        });
    }, { root: slideContainerEl, threshold: .1 });

    document.querySelectorAll('.slide').forEach((slide) => {
        slideObserver.observe(slide);
    });
}



}


