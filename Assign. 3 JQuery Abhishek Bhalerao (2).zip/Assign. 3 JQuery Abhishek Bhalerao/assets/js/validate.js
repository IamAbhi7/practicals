$(document).ready(function() {

  // only for letter
  jQuery.validator.addMethod("lettersonly", function(value, element) {
    return this.optional(element) || /^[a-z ]+$/i.test(value);
  }, "Letters and space only please"); 

  // validation
  $("#main-form").validate({
    rules:{
      username:{
        required: true,
        minlength: 3,
				maxlength: 12,
				lettersonly: true
      },
      password:{
        required: true,
				minlength: 6,
				maxlength: 12
      },
      city:{
        required: true,
        minlength: 2,
				maxlength: 12,
				lettersonly: true
      },
      webserver:{
        required:true
      },
      role:{
        required:true
      },
      sign:{
        required:true
      }
    },
    messages:{
      username:{
        required: 'Please enter user name',
        minlength: 'Please enter minimum 3 letters',
        maxlength: 'Please enter maximum 12 letters',
        lettersonly: 'Please enter only letters and spaces',
      },
      password:{
        required: 'Please enter password',
        minlength: 'Please enter minimum 6 letters',
        maxlength: 'Please enter maximum 12 letters',
      },
      city:{
        required: 'Please enter user name',
        minlength: 'Please enter minimum 3 letters',
        maxlength: 'Please enter maximum 12 letters',
        lettersonly: 'Please enter only letters and spaces',
      },
      webserver:{
        required: 'Please select webserver',
      },
      role:{
        required: 'Please select role',
      },
      sign:{
        required:'Please select atleast one sign-in'
      }
    },
    errorPlacement: function(error, element) 
    {
      if ( element.is(":radio") ) {
        error.appendTo('#role_err');
      } else if ( element.is(":checkbox") ) {
        error.appendTo('#sign_err');
      } else {  
        error.insertAfter( element );
      }
    },
    
  });

});