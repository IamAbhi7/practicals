import { Component } from "@angular/core";

@Component({
  selector:'app-test',
  template:`<h3>Abhishek Bhalerao {{name}}</h3>`,
  styleUrls:['./test.component.scss']
})

export class TestComponent{
    name: string = "Angular";
}