import { Component } from '@angular/core';

@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.scss']
})
export class OperationComponent {

  
  public str = ""
  public s=""
  /**
   * handleClick
   */
  public handleClick() {
    this.str = "Abhishek"

  }

  public handleChange(event : any){
    this.s=event.target.value
  }
}
