import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap/modal';

import { AppComponent } from './app.component';
import { ProductsListComponent } from './modules/products-list/products-list.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ProductService } from './modules/products-list/product-service.service';
import { AddEditProductsComponent } from './modules/add-edit-products/add-edit-products.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DeleteProductComponent } from './modules/delete-product/delete-product.component';
import { NavbarComponent } from './modules/navbar/navbar.component';
import { FooterComponent } from './modules/footer/footer.component';
import { SidebarComponent } from './modules/sidebar/sidebar.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductsListComponent,
    AddEditProductsComponent,
    DeleteProductComponent,
    NavbarComponent,
    FooterComponent,
    SidebarComponent
  ],
  imports: [
    BrowserModule,
    NgxDatatableModule, 
    HttpClientModule,
    ModalModule.forRoot(),
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
